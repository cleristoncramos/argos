# Pacote de dados da demonstração

Dados salvos usados quando `ARGOS_DEMO_MODE=true` (docs/demonstracao.md, seção 2).

- `manifest.json`: ativos, período, data da coleta, fonte, versão congelada e hash SHA-256 de cada CSV.
- `<TICKER>.csv`: histórico diário (Date, Open, High, Low, Close, Adj Close, Volume, Dividends, Stock Splits). Semanal e mensal são derivados localmente.
- `llm_respostas.json`: respostas de LLM validadas e salvas (somente `approved: true` é usado).

Gerar ou regenerar (com internet): `python scripts/gerar_dados_demo.py`.
Conferir a integridade: `python scripts/gerar_dados_demo.py --verify`.

Os dados vêm do Yahoo Finance e servem apenas para a demonstração acadêmica. Conferir os termos de uso antes de publicar os CSV em repositório público.